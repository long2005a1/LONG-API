<?php
/**
 * 自写tdk获取
 * 网站TDK信息查询
 */
header("content-type:application/json; charset=utf-8");

// $url = $_REQUEST['url'];
// //去除https
// $_REQUEST = ["https://", "http://", "/"]; 
// $http_referer = str_replace($_REQUEST, "",$url); 

$url = isset($_GET['url']) ? addslashes(trim($_GET['url'])) : '';
// if(!$url){
// exit('error!');
// }
if(!isset($url) || empty($url) || $url==''){
     $pageinfo = array(
        "code" => false,
        "msg" => "请输入网址！"
    );
    echo json_encode($pageinfo,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
    exit;
} 
$webcode = Httpcode($url);
if($webcode=='200'){
   $content = Httpcontent($url);
   $domain = parse_url($url,PHP_URL_HOST);
   $metarray = get_meta_tags($url); 
   $keyword = $metarray['keywords'];
   $description = $metarray['description'];
   preg_match('/<img.*?src=[\'|\"](.*?)[\'|\"].*?[\/]?>/i', $content, $matches);
   preg_match('/<title>(\s*.*)<\/title>/i', $content, $titlearr);
   $pageinfo = array(
     'code'=>$webcode,
	 'url'=>$url,
	 //'title'=>trimall($titlearr[1]),
	 //标题
	 'title'=>$titlearr[1],
	 'keywords'=>$keyword,
	 'description'=>$description,
   );
}else{
  $pageinfo = array(
     'code'=>$webcode,
	 'title'=>'',
	 'keyword'=>'',
	 'description'=>'',
   );
}
echo json_encode($pageinfo,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
function Httpcontent($url){
  $curl = curl_init();
  $headers = array(
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36 ",
  );
  curl_setopt($curl, CURLOPT_URL, $url);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($curl, CURLOPT_HTTPHEADER,$headers);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
  $response = curl_exec($curl);
  curl_close($curl);
  return $response;
}
function Httpcode($url){
  $curl = curl_init();
  curl_setopt($curl, CURLOPT_URL, $url);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($curl, CURLOPT_HEADER, 1);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($curl, CURLOPT_TIMEOUT,10);
  $content = curl_exec($curl);
  $httpcode = curl_getinfo($curl);
  curl_close($curl);
  return $httpcode['http_code'];
}
function trimall($str){
  $qian=array(" ","　","&nbsp;","\t","\n","\r",",","，","-","'",'"');
  $hou=array("","","","","","","","","","");
  return str_replace($qian,$hou,$str);    
}