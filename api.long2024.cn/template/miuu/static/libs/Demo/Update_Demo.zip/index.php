<?php
// 引入数据库类
require 'Database.php';

// 配置数据库
$dbconfig = array(
	'host' => 'localhost', //数据库服务器
	'port' => '3306', //数据库端口
	'user' => 'Auth', //数据库用户名
	'pwd' => 'Auth', //数据库密码
	'dbname' => 'Auth', //数据库名称
);

if (!defined("SQLITE") && (!$dbconfig["user"] || !$dbconfig["pwd"] || !$dbconfig["dbname"])) {
	exit("请先配置数据库！");
}

// 链接数据库
$DB = new DB($dbconfig['host'], $dbconfig['user'], $dbconfig['pwd'], $dbconfig['dbname'], $dbconfig['port']);

$data = json_decode(file_get_contents("http://nathan.com/api/Index/version?appid=1&url=1.cn&authcode=1e5492d91fc1a9f6667c676bb7a5ef96&webkey=Nathan_Auth"),true); //这是示例的链接

if($data['id'] == 1) {
	print_r($data);
} else {
	echo $data['msg'];
}

$sql = $data['update_sql'];
if(!empty($sql)) {
	$sql=explode(';', $sql);
	$t=0;
	$e=0;
	$error='';
	for ($i=0;$i<count($sql);$i++) {
		if (trim($sql[$i])=='')continue;
		if($DB->query($sql[$i])) {
			++$t;
		} else {
			++$e;
			$error.=$DB->error().'<br/>';
		}
	}
	$add = '<br/>数据库更新：SQL成功'.$t.'句/失败'.$e.'句！';
	echo $add;
}
