<?php
/**
 * Nathan_Auth对接源支付订单查询文件
 * @author Nathan
 * @date 2022-08-22
 * @version 1.0
 * 此文件不会泄漏任何隐私信息，请放心使用
 * 请将此文件放在源支付系统 /app/index/controller/ 目录下
 */

namespace app\index\controller;
use think\facade\Db;
class NathanAuth
{
    /**
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function index()
    {
        $trade_no = input('get.trade_no','','htmlspecialchars');
        $userid = input('get.userid','','htmlspecialchars');
        $Auth = input('get.Auth','','htmlspecialchars');
        if ($Auth == 'NathanAuth'){
            return json(['code'=>200,'msg'=>'文件验证成功']);
        }elseif (empty($trade_no) || empty($userid)) {
            return json(['code'=>0,'msg'=>'订单号与用户ID不能为空']);
        }
        $orderdata = Db::name('ypay_order')->where([
            'trade_no' => $trade_no,
            'user_id' => $userid,
        ])->find();
        if (empty($orderdata)) {
            return json(['code'=>0,'msg'=>'订单不存在']);
        }
        $data = array (
            'name' => $orderdata['name'],
            'type' => $orderdata['type'],
            'trade_no' => $orderdata['trade_no'],
            'out_trade_no' => $orderdata['out_trade_no'],
            'money' => $orderdata['money'],
            'status' => $orderdata['status'],
        );
        return json(['code' => 1,'msg'=>'订单查询成功','data' => $data]);
    }

}