<?php
//从授权站下载源码，系统会自动填写此些信息
return [
    'app_version' => '1.0', //应用版本号
    'app_name' => 'Nathan_Auth', //应用名称
    'app_author' => 'Nathan', //作者名称
    'app_qq' => '2322796106', //客服QQ
    'app_url' => 'auth.nanyinet.com', //应用官方网址
    'authcode' => '123456abcd', //授权码
];
?>