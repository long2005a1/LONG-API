<?php
include("./includes/common.php");
$count = $DB->getColumn("SELECT count(id) FROM `lvxia_apilist` WHERE `status`='1'");
$views = $DB->getColumn("SELECT SUM(views) FROM `lvxia_apilist` WHERE `status`='1'");
$apilist = $DB->getAll("SELECT * FROM `lvxia_apilist` WHERE `status`='1' order by `views` desc");
@header('Content-Type: text/html; charset=UTF-8');

$yllist = $DB->query("SELECT * FROM api_youlian ORDER BY id ASC");

?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <title><?=$system['title']?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="description" content="<?=$system['keywords']?>">
    <meta name="keywords" content="<?=$system['description']?>">
    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="<?=theme?>static/css/naranja.min.css">
    <link rel="stylesheet" href="<?=theme?>static/css/layui.css">
    <link rel="stylesheet" href="<?=theme?>static/css/main.css">
    <link rel="stylesheet" href="<?=theme?>static/css/load.css">
    <link rel="stylesheet" href="<?=theme?>static/css/style.css">
    <link href="https://cdn.staticfile.org/font-awesome/5.2.0/css/all.min.css" rel="stylesheet">
   
   
<script type="text/javascript" src="<?=theme?>static/libs/jquery/jquery-3.2.1.min.js"></script>

<!--<script src="https://cdn.staticfile.org/Swiper/3.4.2/js/swiper.min.js"></script>-->
<!--<script src="https://www.zblogsm.com/zb_users/theme/zblogsm_com/script/theia-sticky-sidebar.min.js"></script>-->
<!-- theia-Sticky-Sidebar -->
<!--<script>  -->
<!--$(document).ready(function(){-->
<!--    $(".side-box").theiaStickySidebar({-->
<!--        additionalMarginTop:0-->
<!--    });-->
<!--});-->
<!--</script>-->
<!-- swiper -->
<!--<script> -->
<!--    var swiper = new Swiper(".swiper-container", {-->
<!--    loop: true,-->
<!--    pagination: ".swiper-pagination",-->
<!--    nextButton: ".swiper-button-next",-->
<!--    prevButton: ".swiper-button-prev",-->
<!--    paginationClickable: true,-->
<!--    spaceBetween: 0,-->
<!--    centeredSlides: true,-->
<!--    autoplay: 5500,-->
<!--    autoplayDisableOnInteraction: false-->
<!--});-->
<!--</script>-->
<!--Headroom-->
<!--<script src="https://cdn.staticfile.org/headroom/0.9.1/headroom.min.js"></script>-->
<!--<script>-->
<!--(function() {-->
<!--    var header = new Headroom(document.querySelector("#header"), {-->
<!--        tolerance: 5,-->
<!--        offset : 100,-->
<!--        classes: {-->
<!--          initial: "animated",-->
<!--          pinned: "slideDown",-->
<!--          unpinned: "slideUp"-->
<!--        }-->
<!--    });-->
<!--    header.init();-->
<!--}());-->
<!--</script>-->

</head>
<body>
<!-- header -->
<!--<div class="ew-header">-->
    <!--<img  href="<?=url?>" src="<?=$system['logo']?>" style="height:40px;padding: 10px;">-->
<!--    <h1 class="logo" style="height:40px;padding: 10px;">-->
<!--			<a href="<?=url?>" title="<?=$system['sysname']?>"><img src="<?= url.$system['logo']?>" alt="<?=$system['sysname']?>"></a>-->
<!--		</h1>-->
<!--    <div class="ew-nav-group">-->
<!--        <div class="nav-toggle"><i class="layui-icon layui-icon-more-vertical"></i></div>-->
<!--        <ul class="layui-nav" lay-filter="ew-header-nav">-->
<!--            <li class="layui-nav-item">-->
<!--                <a href="<?=url?>">首页</a>-->
<!--            </li>-->
<!--                        <li class="layui-nav-item"><a href="<?=url?>/wansi">登录</a></li>-->
<!--            <li class="layui-nav-item"><a href="javascript:;">注册</a></li>-->
<!--                    </ul>-->
<!--    </div>-->
<!--</div>-->

<header id="header" class="card br header--fixed">
	<div class="header container">
		<h1 class="logo">
			<a href="<?=url?>" title="<?=$system['sysname']?>"><img src="<?=$system['logo']?>" alt="<?=$system['name']?>"></a>
		</h1>
		<div id="monavber" class="nav br" data-type="index" data-infoid="">
			<ul class="navbar">
			    <li id="nvabar-item-index"><a href="<?=url?>">首页</a></li>
			    <li id="navbar-category-1"><a href="<?=url?>/wansi">登录</a></li>
			    <li id="navbar-category-2"><a href="javascript:;">注册</a></li>
			</ul>
		</div>
		<div id="mnav"><i class="fas fa-bars"></i></div>
				<div id="search"><i class="fas fa-search"></i></div>
		<div class="search">
			<form name="search" method="get" action="https://www.zblogsm.com/search.php?act=search">
				<input class="br" type="text" name="q" placeholder="请输入关键词..."/>
				<button class="submit br" type="submit" value="搜索"><i class="fas fa-search"></i></button>
			</form>
		</div>
	</div>
</header>
<!--<div class="index-breadcrumb"></div>-->

<!-- banner -->
<div class="ew-banner" style="box-shadow: 0 0 6px rgba(0,0,0,.101562);">
    <div class="layui-container ">
        <div class="layui-row layui-col-space25" style="margin-top: 10px;">
            <div class="layui-col-md6  layui-col-xs12">
                <h1 style="margin-top: 25px;"><b><?=$system['sysname']?></b></h1>
                <p style="margin-bottom: 10px;"><?=$system['gonggao']?></p>
                <div class="ew-banner-btngroup" style="margin-top: 50px;margin-bottom: 50px;">
                    <ul class="layui-nav" style="background-color: white;" lay-filter="ew-header-nav">
                                                <li class="layui-nav-item">
                            <a href="javascript:;" class="layui-btn layui-btn-primary" nav-scroll="pricing">
                                <svg data-v-796d512c="" style="width:20px;position: relative;top: 5px;margin-right: 5px;" aria-hidden="true" focusable="false" data-prefix="fad" data-icon="meteor" role="img" xmlns="http://www.w3.org/2000/svg" viewbox="0 0 512 512" class="svg-inline--fa fa-meteor fa-w-16 h-5 -mb-1 mr-1">
                                    <g data-v-796d512c="" class="fa-group">
                                        <path data-v-796d512c="" fill="currentColor" d="M491.14.7C452.44 12.3 379.34 35 303.44 62c-2.1-7-4-13.5-5.6-18.6a16.06 16.06 0 0 0-20-10.69 16.6 16.6 0 0 0-2.86 1.19C232.54 56 122.14 116.5 60.54 176.4c-1.1 1-2.5 2-3.5 3C-19 255.5-19 378.87 57.09 455s199.48 76 275.55-.1c1-1 2-2.4 3-3.5C395.44 389.8 456 279.3 478.14 237a16.05 16.05 0 0 0-6.64-21.72 15.52 15.52 0 0 0-2.86-1.18c-5.2-1.6-11.6-3.5-18.6-5.6 27-76 49.7-149 61.3-187.7A16.17 16.17 0 0 0 491.14.7zM191.94 448a128 128 0 1 1 128-128 128 128 0 0 1-128 128z" opacity="0.4" class="fa-secondary"></path>
                                        <path data-v-796d512c="" fill="currentColor" d="M191.94 192a128 128 0 1 0 128 128 128 128 0 0 0-128-128zm-32 128a32 32 0 1 1 32-32 32 32 0 0 1-32 32zm48 64a16 16 0 1 1 16-16 16 16 0 0 1-16 16z" class="fa-primary"></path>
                                    </g>
                                </svg>
                                立即登录</a>
                        </li>
                        <li class="layui-nav-item">
                            <a href="javascript:;" class="layui-btn" nav-scroll="pricing">
                                <svg data-v-796d512c="" style="width:20px;position: relative;top: 5px;margin-right: 5px;" data-v-ef02ec52="" xmlns="http://www.w3.org/2000/svg" viewbox="0 0 480 512" class="nui-svg nui-svg-gh inline-block h-6 -mt-1 mr-1">
                                    <path data-v-796d512c="" data-v-ef02ec52="" fill="currentColor" d="M186.1 328.7c0 20.9-10.9 55.1-36.7 55.1s-36.7-34.2-36.7-55.1 10.9-55.1 36.7-55.1 36.7 34.2 36.7 55.1zM480 278.2c0 31.9-3.2 65.7-17.5 95-37.9 76.6-142.1 74.8-216.7 74.8-75.8 0-186.2 2.7-225.6-74.8-14.6-29-20.2-63.1-20.2-95 0-41.9 13.9-81.5 41.5-113.6-5.2-15.8-7.7-32.4-7.7-48.8 0-21.5 4.9-32.3 14.6-51.8 45.3 0 74.3 9 108.8 36 29-6.9 58.8-10 88.7-10 27 0 54.2 2.9 80.4 9.2 34-26.7 63-35.2 107.8-35.2 9.8 19.5 14.6 30.3 14.6 51.8 0 16.4-2.6 32.7-7.7 48.2 27.5 32.4 39 72.3 39 114.2zm-64.3 50.5c0-43.9-26.7-82.6-73.5-82.6-18.9 0-37 3.4-56 6-14.9 2.3-29.8 3.2-45.1 3.2-15.2 0-30.1-.9-45.1-3.2-18.7-2.6-37-6-56-6-46.8 0-73.5 38.7-73.5 82.6 0 87.8 80.4 101.3 150.4 101.3h48.2c70.3 0 150.6-13.4 150.6-101.3zm-82.6-55.1c-25.8 0-36.7 34.2-36.7 55.1s10.9 55.1 36.7 55.1 36.7-34.2 36.7-55.1-10.9-55.1-36.7-55.1z"></path>
                                </svg>
                                立即注册</a>
                        </li>
                                            </ul>
                </div>
            </div>
            <div class="layui-col-md6 layui-col-xs12">
                <div class="ew-banner-right">
                    <img class="show" style="width: 94%;" style="margin-top: 0px!important;" src="<?=theme?>static/picture/home.svg">
                </div>
            </div>
        </div>
    </div>
</div>

<div class="section" style="padding-bottom: 15px;margin-top: 15px;">
    <div class="section-title">
        <h2><?=$system['sysname']?>接口搜索</h2>
        <p>拥有多年管理系统产品开发经验</p>
    </div>
    <div class="layui-container">
        <form class="layui-form contact">
            <div class="layui-form-item">
                <input name="keywords" class="layui-input layui-input-lg" placeholder="搜索API关键词，例如：短网址" lay-vertype="tips" lay-verify="required" required/="">
            </div>
            <div class="layui-form-item">
                <button class="layui-btn layui-btn-primary layui-btn-fluid" lay-filter="searchSubmit" lay-submit="">搜索</button>
            </div>
        </form>
    </div>
</div>

<div class="section" nav-id="product" style="/*box-shadow: 0 0 6px rgba(0,0,0,.101562);*/">
    <div class="section-title" style="font-size: 20px;font-weight:500;">
        <h3>全部接口</h3>
        <p>系统共收录了<span style="color:#fa6400;"><?=$count?></span> 个接口项目</p>
        <p style="font-weight: bold;"><?=$system['sysname']?> 共被调用 <span style="color:#fa6400;"><?=$views?></span> 次</p>
    </div>
    <div class="layui-container" style="padding-bottom: 60px;">
        <div class="layui-row layui-col-space30">
            <div class="layui-row layui-col-space30" id="APIList"></div>
        </div>
        <blockquote class="layui-elem-quote layui-text" style="margin-top: 35px;">上帝说要有光，于是萝莉就掀起了裙子。</blockquote>
    </div>
    <!----youlian---->
    <div class="friend-links container">
            <div class="list-plane-title">
                <div>友情链接 <span class="list-plane-linksdescribe"></span></div>
            </div>
          
            <div class="friend-links-list friend-links-card-list">
               <?php foreach($yllist as $res){?>
                    <a class="friend-links-item-card" href="<?php echo $res['domain']?>" target="_blank">
                        <div class="friend-links-item-icon">
                            <img src="https://yuanxiapi.cn/api/ico/?url=http://m.ksto.cn">
                        </div>
                        <div class="friend-links-item-main">
                            <div class="friend-links-item-title"><?php echo $res['title']?></div>
                            <div class="friend-links-item-description"><?php echo $res['content']?></div>
                        </div>
                    </a>
    			<?php }?>
    		</div>

    </div>
    <!----youlian--ned-->
</div>


<!--youlian-->
<main class="container">

</main>
<!-- footer -->
<div class="ew-footer">
    <div class="layui-container">
        <div class="layui-row layui-col-space30">
            <div class="layui-col-md6">
                <h4 class="footer-item-title">关于我们</h4>
                <p>
                    <i class="layui-icon layui-icon-login-qq"></i>
                    <a href="http://wpa.qq.com/msgrd?v=3&uin=<?=$system['zzqq']?>&site=qq&menu=yes" target="_blank">问题咨询QQ:<?=$system['zzqq']?></a>
                </p>
                <p><a href="/" target="_blank">Copyright © 2022-<?=date('Y')?>  Powered by Vance program.all rights reserved.</a></p>
                <p><a href="https://beian.miit.gov.cn/" target="_blank" rel="nofollow"><img src="<?=theme?>static/picture/icp.png" style="height: 2em; "><?=$system['icp']?></a>&nbsp;&nbsp;&nbsp;
                </p>
            </div>
            <div class="layui-col-md4">
                <h4 style="font-size: 17px;" class="footer-item-title">项目开源</h4>

                    <p><i class="layui-icon layui-icon-component"></i><a href="javascript:;" target="_blank">码云下载</a></p>
                    <p><i class="layui-icon layui-icon-component"></i><a href="javascript:;" target="_blank">githup</a></p>
                    <p><i class="layui-icon layui-icon-component"></i><a href="javascript:;" target="_blank">XiaoYi API使用说明</a></p>
                    <p><i class="layui-icon layui-icon-component"></i><a href="javascript:;" target="_blank">XiaoYi API开发文档</a></p>
     
            </div>
            <div class="layui-col-md2">
                <h2 style="font-size: 17px;" class="footer-item-title">其他项目</h2>
                                <p><i class="layui-icon layui-icon-component"></i><a href="javascript:;" target="_blank">开发中...</a></p>
                                <p><i class="layui-icon layui-icon-component"></i><a href="javascript:;" target="_blank">开发中...</a></p>
                                <p><i class="layui-icon layui-icon-component"></i><a href="javascript:;" target="_blank">开发中...</a></p>
                                <p><i class="layui-icon layui-icon-component"></i><a href="javascript:;" target="_blank">开发中...</a></p>
                            </div>
        </div>
    </div>
</div>
<script type="text/html" id="APIItem">
    <div class="layui-col-md4 layui-col-sm6">
        <div class="product-card" style="border-radius: 6px;overflow: hidden;">
            <div class="product-cover">
                <div class="product-cover-img" style="background-image: url('http://api.nanyinet.com/api/sjbz/api.php?method=pc&amp;lx=mc');"></div>
                <div class="product-tools">
                    <a rel="nofollow" href="https://connect.qq.com/widget/shareqq/index.html?url=<?=url?>api/{{d.alias}}.html&title={{d.name}}&desc={{d.desc}}" target="_blank" class="layui-btn layui-btn-primary">分享</a>
                    <a href="<?=url?>api/{{d.alias}}.html" class="layui-btn layui-btn-primary">详情</a>
                </div>
            </div>
            <div class="product-body">
                <a href="<?=url?>api/{{d.alias}}.html" class="product-title">{{d.name}}</a>
                <p class="product-desc">{{d.desc}}</p>
                <span class="layui-badge-rim">浏览量 {{d.views}}</span>
            </div>
        </div>
    </div>
</script>
<!-- Js 部分 -->
<script type="text/javascript" src="<?=theme?>static/libs/layui/layui.js"></script>
<script type="text/javascript" src="<?=theme?>static/js/common.js"></script>
<script type="text/javascript" src="<?=theme?>static/js/style.js"></script>
<script>
    layui.use(['layer'], function () {
        var layer = layui.layer;
        layer.open({
            type: 1,
            anim: 4,
            title: '<?=$system['sysname']?>服务公告',
            closeBtn: false,
            area: '300px;',
            btn: ['关闭提示'],
            moveType: 1,
            content: '<div style="padding: 40px; line-height: 20px; background-color: #393D49; color: #fff; font-weight: 150;"><b>欢迎使用小易公益API<br>公益API数据接口调用服务平台<br> 致力于为用户提供稳定、快速的免费API数据接口服务。</b></div>',
            success: function(layero) {
                var btn = layero.find('.layui-layer-btn');
            }
        });
    });
</script>
<script>
    layui.use(["jquery", "element", "util",'form', 'dataGrid','layer'], function() {
        var $ = layui.jquery;
        var layer = layui.layer;
        var dataGrid = layui.dataGrid;
        var form = layui.form;
        var f = layui.jquery;
        var e = layui.element;
        var d = layui.util;
        var c = layui.admin;

        if (f(".ew-header").length > 0) {
            var b = [];
            f("[nav-id]").each(function() {
                b.push(f(this).attr("nav-id"))
            });
            if (b.length > 0)
                d.fixbar({
                    bgcolor: '#3EC483',
                    bar1: '&#xe606;',
                    click: function(g) {
                        if (g == "bar1") {
                            window.open("http://wpa.qq.com/msgrd?v=3&uin=<?=$system['zzqq']?>&site=qq&menu=yes")
                        }
                    }
                })
        }

        dataGrid.render({
            elem: '#APIList',
            templet: '#APIItem',
            data: './wansi/ajax.php?act=ApiallInfo',
            loadMore: {limit: 9}
        });

        // 表单提交
        form.on('submit(searchSubmit)', function (obj) {
            var loadIndex = layer.msg('请求中...', {icon: 16, shade: 0.01, time: false});
            $.post('./wansi/serch.php?act=Apiserch', obj.field, function (res) {
                if (200 === res.code) {
                    layer.msg(res.msg, {icon: 1, time: 1500});
                    dataGrid.render({
                        elem: '#APIList',
                        templet: '#APIItem',
                        data: res.data,
                        loadMore: {limit: 9}
                    });
                } else {
                    layer.msg(res.msg, {icon: 2, anim: 6});
                }
            }, 'JSON');
            return false;
        });
    });
</script>
</body>
</html>
